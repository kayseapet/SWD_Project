if ! command -v java &> /dev/null; then
    echo "ERROR: Java is not installed or not in PATH"
    echo "Please install Java JDK 8 or higher"
    echo "You can install it using: brew install openjdk"
    read -p "Press Enter to exit..."
    exit 1
fi


APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$APP_DIR/src/main/java"
RESOURCES_DIR="$APP_DIR/src/resources"
BUILD_DIR="$APP_DIR/build"
MYSQL_JAR="$RESOURCES_DIR/mysql-connector-j-9.4.0.jar"


if [ ! -d "$SRC_DIR" ]; then
    echo "ERROR: Source directory not found: $SRC_DIR"
    echo "Please ensure your Java source files are in src/main/java/"
    read -p "Press Enter to exit..."
    exit 1
fi


if [ ! -f "$MYSQL_JAR" ]; then
    echo "ERROR: MySQL connector JAR not found: $MYSQL_JAR"
    echo "Please ensure mysql-connector-j-9.4.0.jar is in src/resources/"
    read -p "Press Enter to exit..."
    exit 1
fi


if [ ! -d "$BUILD_DIR" ]; then
    mkdir -p "$BUILD_DIR"
fi

echo ""
echo "Compiling Java source files..."
echo "Source directory: $SRC_DIR"
echo "Build directory: $BUILD_DIR"
echo "MySQL JAR: $MYSQL_JAR"


javac -cp "$MYSQL_JAR" -d "$BUILD_DIR" "$SRC_DIR"/*.java

if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: Compilation failed!"
    echo "Please check your Java source files for errors."
    read -p "Press Enter to exit..."
    exit 1
fi

echo "Compilation successful!"
echo ""
echo "Starting Employee Management System..."
echo ""


java -cp "$BUILD_DIR:$MYSQL_JAR" Main

echo ""
echo "Application ended."
read -p "Press Enter to exit..."