import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class Employee {
    private int empId;
    private String firstName;
    private String lastName;
    private String ssn;
    private String jobTitle;
    private String division;
    private double salary;
    private LocalDate hireDate;
    private List<PayStatement> payStatements;

    public Employee() {
        this.payStatements = new ArrayList<>();
    }

    public Employee(int empId, String firstName, String lastName, String ssn,
            String jobTitle, String division, double salary, LocalDate hireDate) {
        this.empId = empId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.ssn = ssn;
        this.jobTitle = jobTitle;
        this.division = division;
        this.salary = salary;
        this.hireDate = hireDate;
        this.payStatements = new ArrayList<>();
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    public List<PayStatement> getPayStatements() {
        return payStatements;
    }

    public void setPayStatements(List<PayStatement> payStatements) {
        this.payStatements = payStatements;
    }

    @Override
    public String toString() {
        return String.format(
                "Employee [ID: %d, Name: %s %s, SSN: %s, Title: %s, Division: %s, Salary: $%.2f, Hire Date: %s]",
                empId, firstName, lastName, ssn, jobTitle, division, salary, hireDate);
    }
}