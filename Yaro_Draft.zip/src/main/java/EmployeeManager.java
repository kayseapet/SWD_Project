import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EmployeeManager {
    private DatabaseConnection dbConnection;

    public EmployeeManager() {
        this.dbConnection = new DatabaseConnection();
    }

    public boolean initializeDatabase() {
        if (!dbConnection.createDatabaseIfNotExists()) {
            System.err.println("Failed to create database");
            return false;
        }

        return dbConnection.createTablesIfNotExist() && dbConnection.addSSNColumn();
    }

    public List<Employee> searchEmployee(String searchTerm, String searchType) {
        List<Employee> results = new ArrayList<>();
        String sql = "";

        switch (searchType.toLowerCase()) {
            case "id":
                sql = "SELECT * FROM employees WHERE emp_id = ?";
                break;
            case "name":
                sql = "SELECT * FROM employees WHERE CONCAT(first_name, ' ', last_name) LIKE ?";
                break;
            case "ssn":
                sql = "SELECT * FROM employees WHERE ssn = ?";
                break;
            default:
                System.out.println("Invalid search type. Use: id, name, or ssn");
                return results;
        }

        try (Connection conn = dbConnection.connect();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            if (searchType.equals("name")) {
                stmt.setString(1, "%" + searchTerm + "%");
            } else {
                stmt.setString(1, searchTerm);
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Employee emp = createEmployeeFromResultSet(rs);
                results.add(emp);
            }
        } catch (SQLException e) {
            System.err.println("Error searching for employee: " + e.getMessage());
        }

        return results;
    }

    public boolean addEmployee(Employee employee) {
        String sql = "INSERT INTO employees (first_name, last_name, job_title, division, salary, hire_date, ssn) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = dbConnection.connect();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, employee.getFirstName());
            stmt.setString(2, employee.getLastName());
            stmt.setString(3, employee.getJobTitle());
            stmt.setString(4, employee.getDivision());
            stmt.setDouble(5, employee.getSalary());
            stmt.setDate(6, Date.valueOf(employee.getHireDate()));
            stmt.setString(7, employee.getSsn());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error adding employee: " + e.getMessage());
            return false;
        }
    }

    public boolean updateEmployee(Employee employee) {
        String sql = "UPDATE employees SET first_name = ?, last_name = ?, job_title = ?, division = ?, salary = ?, hire_date = ?, ssn = ? WHERE emp_id = ?";

        try (Connection conn = dbConnection.connect();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, employee.getFirstName());
            stmt.setString(2, employee.getLastName());
            stmt.setString(3, employee.getJobTitle());
            stmt.setString(4, employee.getDivision());
            stmt.setDouble(5, employee.getSalary());
            stmt.setDate(6, Date.valueOf(employee.getHireDate()));
            stmt.setString(7, employee.getSsn());
            stmt.setInt(8, employee.getEmpId());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating employee: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteEmployee(int empId) {
        String sql = "DELETE FROM employees WHERE emp_id = ?";

        try (Connection conn = dbConnection.connect();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, empId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting employee: " + e.getMessage());
            return false;
        }
    }

    public boolean updateSalaryRange(double percentage, double minSalary, double maxSalary) {
        String sql = "UPDATE employees SET salary = salary * (1 + ? / 100) WHERE salary >= ? AND salary < ?";

        try (Connection conn = dbConnection.connect();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, percentage);
            stmt.setDouble(2, minSalary);
            stmt.setDouble(3, maxSalary);

            int rowsAffected = stmt.executeUpdate();
            System.out.println(rowsAffected + " employees received salary increase of " + percentage + "%");
            return rowsAffected >= 0;
        } catch (SQLException e) {
            System.err.println("Error updating salary range: " + e.getMessage());
            return false;
        }
    }

    private Employee createEmployeeFromResultSet(ResultSet rs) throws SQLException {
        Employee emp = new Employee();
        emp.setEmpId(rs.getInt("emp_id"));
        emp.setFirstName(rs.getString("first_name"));
        emp.setLastName(rs.getString("last_name"));
        emp.setSsn(rs.getString("ssn"));
        emp.setJobTitle(rs.getString("job_title"));
        emp.setDivision(rs.getString("division"));
        emp.setSalary(rs.getDouble("salary"));

        Date hireDate = rs.getDate("hire_date");
        if (hireDate != null) {
            emp.setHireDate(hireDate.toLocalDate());
        }

        return emp;
    }

    public List<Employee> getAllEmployees() {
        return dbConnection.getAllEmployees();
    }

    public void closeConnection() {
        dbConnection.disconnect();
    }
}