import java.time.LocalDate;

public class PayStatement {
    private int payId;
    private int empId;
    private LocalDate payPeriod;
    private double grossPay;
    private double deductions;
    private double netPay;

    public PayStatement() {
    }

    public PayStatement(int payId, int empId, LocalDate payPeriod,
            double grossPay, double deductions, double netPay) {
        this.payId = payId;
        this.empId = empId;
        this.payPeriod = payPeriod;
        this.grossPay = grossPay;
        this.deductions = deductions;
        this.netPay = netPay;
    }

    public int getPayId() {
        return payId;
    }

    public void setPayId(int payId) {
        this.payId = payId;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public LocalDate getPayPeriod() {
        return payPeriod;
    }

    public void setPayPeriod(LocalDate payPeriod) {
        this.payPeriod = payPeriod;
    }

    public double getGrossPay() {
        return grossPay;
    }

    public void setGrossPay(double grossPay) {
        this.grossPay = grossPay;
    }

    public double getDeductions() {
        return deductions;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }

    public double getNetPay() {
        return netPay;
    }

    public void setNetPay(double netPay) {
        this.netPay = netPay;
    }

    @Override
    public String toString() {
        return String.format(
                "Pay Statement [ID: %d, Employee ID: %d, Period: %s, Gross: $%.2f, Deductions: $%.2f, Net: $%.2f]",
                payId, empId, payPeriod, grossPay, deductions, netPay);
    }
}