import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DatabaseConnection {
    private static final String DB_HOST = "localhost:3306";
    private static final String DB_NAME = "employee_db";
    private static final String DB_URL = "jdbc:mysql://" + DB_HOST + "/" + DB_NAME;
    private static final String DB_URL_WITHOUT_DB = "jdbc:mysql://" + DB_HOST;
    private static final String USERNAME = "root";
    private static final String PASSWORD = "password";

    private Connection connection;

    public DatabaseConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found: " + e.getMessage());
        }
    }

    public boolean createDatabaseIfNotExists() {
        try (Connection conn = DriverManager.getConnection(DB_URL_WITHOUT_DB, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement()) {

            String createDatabaseSQL = "CREATE DATABASE IF NOT EXISTS " + DB_NAME +
                    " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
            stmt.executeUpdate(createDatabaseSQL);

            System.out.println("Database '" + DB_NAME + "' is ready.");
            return true;

        } catch (SQLException e) {
            System.err.println("Error creating database: " + e.getMessage());
            System.err.println("Please ensure MySQL is running and credentials are correct.");
            return false;
        }
    }

    public Connection connect() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
        }
        return connection;
    }

    public void disconnect() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing database connection: " + e.getMessage());
        }
    }

    public boolean columnExists(String tableName, String columnName) {
        try (Connection conn = connect()) {
            DatabaseMetaData metaData = conn.getMetaData();
            ResultSet columns = metaData.getColumns(null, null, tableName, columnName);
            return columns.next();
        } catch (SQLException e) {
            System.err.println("Error checking column existence: " + e.getMessage());
            return false;
        }
    }

    public boolean addSSNColumn() {
        if (columnExists("employees", "ssn")) {
            System.out.println("SSN column already exists");
            return true;
        }

        try (Connection conn = connect();
                Statement stmt = conn.createStatement()) {

            String addSSNColumn = "ALTER TABLE employees ADD COLUMN ssn CHAR(9)";
            stmt.execute(addSSNColumn);
            System.out.println("SSN column added successfully");
            return true;
        } catch (SQLException e) {
            System.err.println("Error adding SSN column: " + e.getMessage());
            return false;
        }
    }

    public boolean createTablesIfNotExist() {
        try {
            connect();

            String createEmployeesTable = """
                        CREATE TABLE IF NOT EXISTS employees (
                            emp_id INT PRIMARY KEY AUTO_INCREMENT,
                            first_name VARCHAR(50) NOT NULL,
                            last_name VARCHAR(50) NOT NULL,
                            job_title VARCHAR(100),
                            division VARCHAR(50),
                            salary DECIMAL(10,2),
                            hire_date DATE,
                            ssn CHAR(9)
                        )
                    """;

            String createPayStatementsTable = """
                        CREATE TABLE IF NOT EXISTS pay_statements (
                            pay_id INT PRIMARY KEY AUTO_INCREMENT,
                            emp_id INT,
                            pay_period DATE,
                            gross_pay DECIMAL(10,2),
                            deductions DECIMAL(10,2),
                            net_pay DECIMAL(10,2),
                            FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
                        )
                    """;

            try (Statement stmt = connection.createStatement()) {
                stmt.execute(createEmployeesTable);
                stmt.execute(createPayStatementsTable);
                System.out.println("Database tables created successfully");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error creating tables: " + e.getMessage());
            return false;
        }
    }

    public List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        String sql = "SELECT * FROM employees ORDER BY emp_id";

        try (PreparedStatement stmt = connect().prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Employee emp = new Employee();
                emp.setEmpId(rs.getInt("emp_id"));
                emp.setFirstName(rs.getString("first_name"));
                emp.setLastName(rs.getString("last_name"));
                emp.setSsn(rs.getString("ssn"));
                emp.setJobTitle(rs.getString("job_title"));
                emp.setDivision(rs.getString("division"));
                emp.setSalary(rs.getDouble("salary"));

                Date hireDate = rs.getDate("hire_date");
                if (hireDate != null) {
                    emp.setHireDate(hireDate.toLocalDate());
                }

                employees.add(emp);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving employees: " + e.getMessage());
        }

        return employees;
    }

    public ResultSet executeQuery(String sql) throws SQLException {
        Statement stmt = connect().createStatement();
        return stmt.executeQuery(sql);
    }

    public int executeUpdate(String sql) throws SQLException {
        Statement stmt = connect().createStatement();
        return stmt.executeUpdate(sql);
    }
}