import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class ConsoleUI {
    private Scanner scanner;
    private EmployeeManager employeeManager;
    private ReportGenerator reportGenerator;

    public ConsoleUI() {
        this.scanner = new Scanner(System.in);
        this.employeeManager = new EmployeeManager();
        this.reportGenerator = new ReportGenerator();
    }

    private void clearScreen() {
        try {
            String os = System.getProperty("os.name").toLowerCase();
            ProcessBuilder pb;

            if (os.contains("win")) {
                pb = new ProcessBuilder("cmd", "/c", "cls");
            } else {
                pb = new ProcessBuilder("clear");
            }

            pb.inheritIO();
            Process process = pb.start();
            process.waitFor();
        } catch (Exception e) {
            clearScreen();
        }
    }

    public void start() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        if (!employeeManager.initializeDatabase()) {
            System.err.println("Failed to initialize database. Exiting...");
            return;
        }

        displayMainMenu();
    }

    private void displayMainMenu() {
        while (true) {
            clearScreen();
            System.out.println("=".repeat(60));
            System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
            System.out.println("=".repeat(60));
            System.out.println("\n" + "=".repeat(40));
            System.out.println("MAIN MENU");
            System.out.println("=".repeat(40));
            System.out.println("1. Employee Management");
            System.out.println("2. Reports");
            System.out.println("3. Add Sample Data");
            System.out.println("4. Clear Sample Data");
            System.out.println("0. Exit");
            System.out.print("\nSelect an option: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    displayEmployeeMenu();
                    break;
                case "2":
                    displayReportsMenu();
                    break;
                case "3":
                    addSampleData();
                    break;
                case "4":
                    clearAllData();
                    break;
                case "0":
                    exitApplication();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
                    System.out.print("Press Enter to continue...");
                    scanner.nextLine();
            }
        }
    }

    private void displayEmployeeMenu() {
        while (true) {
            clearScreen();
            System.out.println("=".repeat(60));
            System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
            System.out.println("=".repeat(60));
            System.out.println("\n" + "=".repeat(40));
            System.out.println("EMPLOYEE MANAGEMENT");
            System.out.println("=".repeat(40));
            System.out.println("1. Add Employee");
            System.out.println("2. Search Employee");
            System.out.println("3. Update Employee");
            System.out.println("4. Delete Employee");
            System.out.println("5. List All Employees");
            System.out.println("6. Update Salary Range");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nSelect an option: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    clearScreen();
                    addEmployee();
                    break;
                case "2":
                    clearScreen();
                    searchEmployee();
                    break;
                case "3":
                    clearScreen();
                    updateEmployee();
                    break;
                case "4":
                    clearScreen();
                    deleteEmployee();
                    break;
                case "5":
                    clearScreen();
                    listAllEmployees();
                    break;
                case "6":
                    clearScreen();
                    updateSalaryRange();
                    break;
                case "0":
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
                    System.out.print("Press Enter to continue...");
                    scanner.nextLine();
            }
        }
    }

    private void displayReportsMenu() {
        while (true) {
            clearScreen();
            System.out.println("=".repeat(60));
            System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
            System.out.println("=".repeat(60));
            System.out.println("\n" + "=".repeat(40));
            System.out.println("REPORTS");
            System.out.println("=".repeat(40));
            System.out.println("1. Employee Pay History");
            System.out.println("2. Monthly Pay by Job Title");
            System.out.println("3. Monthly Pay by Division");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nSelect an option: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    clearScreen();
                    generatePayHistoryReport();
                    break;
                case "2":
                    clearScreen();
                    generateJobTitleReport();
                    break;
                case "3":
                    clearScreen();
                    generateDivisionReport();
                    break;
                case "0":
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
                    System.out.print("Press Enter to continue...");
                    scanner.nextLine();
            }
        }
    }

    private void addEmployee() {
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- ADD NEW EMPLOYEE ---");

        System.out.print("First Name: ");
        String firstName = scanner.nextLine().trim();

        System.out.print("Last Name: ");
        String lastName = scanner.nextLine().trim();

        System.out.print("Job Title: ");
        String jobTitle = scanner.nextLine().trim();

        System.out.print("Division: ");
        String division = scanner.nextLine().trim();

        double salary = 0;
        while (true) {
            System.out.print("Salary: ");
            try {
                salary = Double.parseDouble(scanner.nextLine().trim());
                if (salary >= 0)
                    break;
                System.out.println("Salary must be non-negative.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid salary format. Please enter a number.");
            }
        }

        LocalDate hireDate = null;
        while (true) {
            System.out.print("Hire Date (YYYY-MM-DD): ");
            try {
                hireDate = LocalDate.parse(scanner.nextLine().trim());
                break;
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Please use YYYY-MM-DD.");
            }
        }

        String ssn = "";
        while (true) {
            System.out.print("SSN (9 digits, no dashes): ");
            ssn = scanner.nextLine().trim();
            if (ssn.matches("\\d{9}")) {
                break;
            }
            System.out.println("SSN must be exactly 9 digits with no dashes.");
        }

        Employee employee = new Employee(0, firstName, lastName, ssn, jobTitle, division, salary, hireDate);

        if (employeeManager.addEmployee(employee)) {
            System.out.println("Employee added successfully!");
        } else {
            System.out.println("Failed to add employee.");
        }

        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void searchEmployee() {
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- SEARCH EMPLOYEE ---");
        System.out.println("1. Search by ID");
        System.out.println("2. Search by Name");
        System.out.println("3. Search by SSN");
        System.out.print("Select search type: ");

        String searchChoice = scanner.nextLine().trim();
        String searchType = "";
        String prompt = "";

        switch (searchChoice) {
            case "1":
                searchType = "id";
                prompt = "Enter Employee ID: ";
                break;
            case "2":
                searchType = "name";
                prompt = "Enter Name (partial or full): ";
                break;
            case "3":
                searchType = "ssn";
                prompt = "Enter SSN (9 digits): ";
                break;
            default:
                System.out.println("Invalid search type.");
                System.out.print("Press Enter to continue...");
                scanner.nextLine();
                return;
        }

        System.out.print(prompt);
        String searchTerm = scanner.nextLine().trim();

        List<Employee> results = employeeManager.searchEmployee(searchTerm, searchType);

        if (results.isEmpty()) {
            System.out.println("No employees found matching your search criteria.");
        } else {
            System.out.println("\nSearch Results:");
            System.out.println("-".repeat(100));
            for (Employee emp : results) {
                System.out.println(emp);
            }
        }

        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void updateEmployee() {
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- UPDATE EMPLOYEE ---");
        System.out.print("Enter Employee ID to update: ");

        try {
            int empId = Integer.parseInt(scanner.nextLine().trim());
            List<Employee> employees = employeeManager.searchEmployee(String.valueOf(empId), "id");

            if (employees.isEmpty()) {
                System.out.println("Employee not found.");
                System.out.print("Press Enter to continue...");
                scanner.nextLine();
                return;
            }

            Employee employee = employees.get(0);
            System.out.println("Current employee information:");
            System.out.println(employee);
            System.out.println();

            System.out.print("First Name [" + employee.getFirstName() + "]: ");
            String firstName = scanner.nextLine().trim();
            if (!firstName.isEmpty())
                employee.setFirstName(firstName);

            System.out.print("Last Name [" + employee.getLastName() + "]: ");
            String lastName = scanner.nextLine().trim();
            if (!lastName.isEmpty())
                employee.setLastName(lastName);

            System.out.print("Job Title [" + employee.getJobTitle() + "]: ");
            String jobTitle = scanner.nextLine().trim();
            if (!jobTitle.isEmpty())
                employee.setJobTitle(jobTitle);

            System.out.print("Division [" + employee.getDivision() + "]: ");
            String division = scanner.nextLine().trim();
            if (!division.isEmpty())
                employee.setDivision(division);

            System.out.print("Salary [" + employee.getSalary() + "]: ");
            String salaryInput = scanner.nextLine().trim();
            if (!salaryInput.isEmpty()) {
                try {
                    double salary = Double.parseDouble(salaryInput);
                    if (salary >= 0)
                        employee.setSalary(salary);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid salary format, keeping current value.");
                }
            }

            System.out.print("Hire Date [" + employee.getHireDate() + "] (YYYY-MM-DD): ");
            String hireDateInput = scanner.nextLine().trim();
            if (!hireDateInput.isEmpty()) {
                try {
                    LocalDate hireDate = LocalDate.parse(hireDateInput);
                    employee.setHireDate(hireDate);
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date format, keeping current value.");
                }
            }

            System.out.print("SSN [" + employee.getSsn() + "] (9 digits): ");
            String ssnInput = scanner.nextLine().trim();
            if (!ssnInput.isEmpty()) {
                if (ssnInput.matches("\\d{9}")) {
                    employee.setSsn(ssnInput);
                } else {
                    System.out.println("Invalid SSN format, keeping current value.");
                }
            }

            if (employeeManager.updateEmployee(employee)) {
                System.out.println("Employee updated successfully!");
            } else {
                System.out.println("Failed to update employee.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Invalid Employee ID format.");
        }

        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void deleteEmployee() {
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- DELETE EMPLOYEE ---");
        System.out.print("Enter Employee ID to delete: ");

        try {
            int empId = Integer.parseInt(scanner.nextLine().trim());
            List<Employee> employees = employeeManager.searchEmployee(String.valueOf(empId), "id");

            if (employees.isEmpty()) {
                System.out.println("Employee not found.");
                System.out.print("Press Enter to continue...");
                scanner.nextLine();
                return;
            }

            Employee employee = employees.get(0);
            System.out.println("Employee to delete:");
            System.out.println(employee);

            System.out.print("Are you sure you want to delete this employee? (y/N): ");
            String confirmation = scanner.nextLine().trim().toLowerCase();

            if (confirmation.equals("y") || confirmation.equals("yes")) {
                if (employeeManager.deleteEmployee(empId)) {
                    System.out.println("Employee deleted successfully!");
                } else {
                    System.out.println("Failed to delete employee.");
                }
            } else {
                System.out.println("Delete operation cancelled.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Invalid Employee ID format.");
        }

        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void listAllEmployees() {
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- ALL EMPLOYEES ---");
        List<Employee> employees = employeeManager.getAllEmployees();

        if (employees.isEmpty()) {
            System.out.println("No employees found in the database.");
        } else {
            System.out.println("Total employees: " + employees.size());
            System.out.println("-".repeat(100));
            for (Employee emp : employees) {
                System.out.println(emp);
            }
        }

        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void updateSalaryRange() {
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- UPDATE SALARY RANGE ---");

        double percentage = 0;
        while (true) {
            System.out.print("Enter percentage increase (e.g., 3.2 for 3.2%): ");
            try {
                percentage = Double.parseDouble(scanner.nextLine().trim());
                if (percentage > 0)
                    break;
                System.out.println("Percentage must be positive.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid percentage format.");
            }
        }

        double minSalary = 0;
        while (true) {
            System.out.print("Enter minimum salary (inclusive): ");
            try {
                minSalary = Double.parseDouble(scanner.nextLine().trim());
                if (minSalary >= 0)
                    break;
                System.out.println("Salary must be non-negative.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid salary format.");
            }
        }

        double maxSalary = 0;
        while (true) {
            System.out.print("Enter maximum salary (exclusive): ");
            try {
                maxSalary = Double.parseDouble(scanner.nextLine().trim());
                if (maxSalary > minSalary)
                    break;
                System.out.println("Maximum salary must be greater than minimum salary.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid salary format.");
            }
        }

        System.out.printf("This will apply %.2f%% increase to employees earning between $%.2f and $%.2f\n",
                percentage, minSalary, maxSalary);
        System.out.print("Proceed? (y/N): ");

        String confirmation = scanner.nextLine().trim().toLowerCase();
        if (confirmation.equals("y") || confirmation.equals("yes")) {
            if (employeeManager.updateSalaryRange(percentage, minSalary, maxSalary)) {
                System.out.println("Salary range update completed successfully!");
            } else {
                System.out.println("Failed to update salary range.");
            }
        } else {
            System.out.println("Salary update cancelled.");
        }

        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void generatePayHistoryReport() {
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- EMPLOYEE PAY HISTORY REPORT ---");
        System.out.print("Enter Employee ID: ");

        try {
            int empId = Integer.parseInt(scanner.nextLine().trim());
            reportGenerator.generateEmployeePayHistoryReport(empId);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Employee ID format.");
        }

        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void generateJobTitleReport() {
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- MONTHLY PAY BY JOB TITLE REPORT ---");

        int year = 0;
        while (true) {
            System.out.print("Enter year (e.g., 2024): ");
            try {
                year = Integer.parseInt(scanner.nextLine().trim());
                if (year > 1900 && year <= 2100)
                    break;
                System.out.println("Please enter a valid year.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid year format.");
            }
        }

        int month = 0;
        while (true) {
            System.out.print("Enter month (1-12): ");
            try {
                month = Integer.parseInt(scanner.nextLine().trim());
                if (month >= 1 && month <= 12)
                    break;
                System.out.println("Month must be between 1 and 12.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid month format.");
            }
        }

        reportGenerator.generateMonthlyPayByJobTitle(year, month);

        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void generateDivisionReport() {
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- MONTHLY PAY BY DIVISION REPORT ---");

        int year = 0;
        while (true) {
            System.out.print("Enter year (e.g., 2024): ");
            try {
                year = Integer.parseInt(scanner.nextLine().trim());
                if (year > 1900 && year <= 2100)
                    break;
                System.out.println("Please enter a valid year.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid year format.");
            }
        }

        int month = 0;
        while (true) {
            System.out.print("Enter month (1-12): ");
            try {
                month = Integer.parseInt(scanner.nextLine().trim());
                if (month >= 1 && month <= 12)
                    break;
                System.out.println("Month must be between 1 and 12.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid month format.");
            }
        }

        reportGenerator.generateMonthlyPayByDivision(year, month);

        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void addSampleData() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- ADD SAMPLE DATA ---");
        Employee[] sampleEmployees = {
                new Employee(0, "Adam", "Apple", "123456789", "Software Engineer", "IT", 75000,
                        LocalDate.of(2022, 1, 15)),
                new Employee(0, "Bob", "Builder", "987654321", "Project Manager", "IT", 85000,
                        LocalDate.of(2021, 3, 10)),
                new Employee(0, "Cathy", "Cat", "456789123", "Data Analyst", "Analytics", 65000,
                        LocalDate.of(2023, 6, 1)),
                new Employee(0, "Dave", "Dunce", "789123456", "Data Analyst", "Analytics", 55000,
                        LocalDate.of(2022, 8, 20)),
                new Employee(0, "Eric", "Ericson", "321654987", "Marketing Manager", "Marketing", 90000,
                        LocalDate.of(2021, 11, 5)),
                new Employee(0, "Frank", "Fuzzy", "654987321", "Marketing Representative", "Marketing", 75000,
                        LocalDate.of(2020, 2, 14)),
                new Employee(0, "Gary", "Gee", "147258369", "Sales Representative", "Sales", 45000,
                        LocalDate.of(2023, 9, 12)),
                new Employee(0, "Harry", "Hotshot", "258369147", "Sales Representative", "Sales", 50000,
                        LocalDate.of(2022, 4, 18))
        };

        int addedEmployees = 0;
        for (Employee emp : sampleEmployees) {
            if (employeeManager.addEmployee(emp)) {
                addedEmployees++;
            }
        }

        System.out.println("Added " + addedEmployees + " sample employees.");

        try {
            DatabaseConnection dbConnection = new DatabaseConnection();

            String[] payStatements = {
                    "INSERT INTO pay_statements (emp_id, pay_period, gross_pay, deductions, net_pay) VALUES (1, '2024-01-31', 6250.00, 1875.00, 4375.00)",
                    "INSERT INTO pay_statements (emp_id, pay_period, gross_pay, deductions, net_pay) VALUES (1, '2024-02-29', 6250.00, 1875.00, 4375.00)",
                    "INSERT INTO pay_statements (emp_id, pay_period, gross_pay, deductions, net_pay) VALUES (2, '2024-01-31', 7083.33, 2125.00, 4958.33)",
                    "INSERT INTO pay_statements (emp_id, pay_period, gross_pay, deductions, net_pay) VALUES (2, '2024-02-29', 7083.33, 2125.00, 4958.33)",
                    "INSERT INTO pay_statements (emp_id, pay_period, gross_pay, deductions, net_pay) VALUES (3, '2024-01-31', 5416.67, 1625.00, 3791.67)",
                    "INSERT INTO pay_statements (emp_id, pay_period, gross_pay, deductions, net_pay) VALUES (4, '2024-01-31', 4583.33, 1375.00, 3208.33)",
                    "INSERT INTO pay_statements (emp_id, pay_period, gross_pay, deductions, net_pay) VALUES (5, '2024-01-31', 5833.33, 1750.00, 4083.33)",
                    "INSERT INTO pay_statements (emp_id, pay_period, gross_pay, deductions, net_pay) VALUES (6, '2024-01-31', 7916.67, 2375.00, 5541.67)",
                    "INSERT INTO pay_statements (emp_id, pay_period, gross_pay, deductions, net_pay) VALUES (7, '2024-01-31', 3750.00, 1125.00, 2625.00)",
                    "INSERT INTO pay_statements (emp_id, pay_period, gross_pay, deductions, net_pay) VALUES (8, '2024-01-31', 5000.00, 1500.00, 3500.00)"
            };

            int addedPayStatements = 0;
            for (String sql : payStatements) {
                try {
                    dbConnection.executeUpdate(sql);
                    addedPayStatements++;
                } catch (Exception e) {
                }
            }

            dbConnection.disconnect();
            System.out.println("Added " + addedPayStatements + " sample pay statements.");

        } catch (Exception e) {
            System.err.println("Error adding sample pay statements: " + e.getMessage());
        }

        System.out.println("Sample data loading completed!");
        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void clearAllData() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\n--- CLEAR ALL DATA ---");
        try {
            DatabaseConnection dbConnection = new DatabaseConnection();

            int payStatementsDeleted = dbConnection.executeUpdate("DELETE FROM pay_statements");
            int employeesDeleted = dbConnection.executeUpdate("DELETE FROM employees");
            dbConnection.executeUpdate("ALTER TABLE pay_statements AUTO_INCREMENT = 1");
            dbConnection.executeUpdate("ALTER TABLE employees AUTO_INCREMENT = 1");

            dbConnection.disconnect();

            System.out.println(
                    "Deleted " + payStatementsDeleted + " pay statements and " + employeesDeleted + " employees.");
            System.out.println("All data cleared successfully!");

        } catch (Exception e) {
            System.err.println("Error clearing data: " + e.getMessage());
        }

        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private void exitApplication() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("       EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("=".repeat(60));
        System.out.println("\nClosing database connections...");
        employeeManager.closeConnection();
        System.out.println("Thank you for using Employee Management System!");
        System.out.println("Goodbye!");
    }
}