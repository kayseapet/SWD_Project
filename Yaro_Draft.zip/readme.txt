Ensure you have the following installed:

Java Development Kit (JDK): Version 8 or higher
MySQL Server: Version 8.0 or higher
Ensure MySQL Server is running on your system.


Verify the database connection settings in src\main\java\DatabaseConnection.java:

private static final String DB_HOST = "localhost:3306";
private static final String DB_NAME = "employee_db";
private static final String USERNAME = "root";
private static final String PASSWORD = "password";

Update the USERNAME and PASSWORD to match your MySQL server credentials if necessary.

